<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS><TS version="2.0" language="tr" sourcelanguage="">
<context>
    <name>AboutDialog</name>
    <message>
        <location filename="../ffmulticonverter/about_dlg.py" line="39"/>
        <source>&amp;Close</source>
        <translation>&amp;Kapat</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/about_dlg.py" line="52"/>
        <source>About FF Multi Converter</source>
        <translation>FF Multi Converter Hakkında</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/about_dlg.py" line="38"/>
        <source>C&amp;redits</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AddorEditPreset</name>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="393"/>
        <source>Preset name (one word, A-z, 0-9)</source>
        <translation>Ön ayar adı (tek sözcük, A-z,0-9)</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="395"/>
        <source>Preset label</source>
        <translation>Ön ayar etiketi</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="397"/>
        <source>Preset command line parameters</source>
        <translation>Ön ayar komut satırı değişkenleri</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="399"/>
        <source>Output file extension</source>
        <translation>Çıktı dosyası uzantısı</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="403"/>
        <source>Edit %1</source>
        <translation type="obsolete">%1&apos;i düzenle</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="425"/>
        <source>Add preset</source>
        <translation>Ön ayar ekle</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="486"/>
        <source>Error!</source>
        <translation>Hata!</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="446"/>
        <source>Preset name can&apos;t be left blank.</source>
        <translation>Ön ayar adı boş bırakılamaz.</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="434"/>
        <source>Preset name must be one word and contain only letters and digits.</source>
        <translation type="obsolete">Ön ayar adı tek sözcük olup harf ve rakamlardan oluşmalı.</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="465"/>
        <source>Preset label can&apos;t be left blank.</source>
        <translation>Ön ayar etiketi boş bırakılamaz.</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="472"/>
        <source>Command label can&apos;t be left blank.</source>
        <translation>Komut etiketi boş bırakılamaz.</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="479"/>
        <source>Extension label can&apos;t be left blank.</source>
        <translation>Uzantı etiketi boş bırakılamaz.</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="453"/>
        <source>Extension must be one word and must not start with a dot.</source>
        <translation type="obsolete">Uzantı tek sözcük olup nokta ile başlamamalı.</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="423"/>
        <source>Edit {0}</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="486"/>
        <source>Extension must be one word and must not start with a  dot.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="454"/>
        <source>Preset name must be one word, start with a letter and contain only letters, digits, underscores, hyphens, colons and periods. It cannot also start with xml.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AudioVideoTab</name>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="598"/>
        <source>No Change</source>
        <translation type="obsolete">Değişiklik yok</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="60"/>
        <source>Convert to:</source>
        <translation>Dönüştür:</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="607"/>
        <source>Other</source>
        <translation type="obsolete">Diğer</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="74"/>
        <source>Command:</source>
        <translation>Komut:</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="76"/>
        <source>Preset</source>
        <translation>Ön ayar</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="37"/>
        <source>Default</source>
        <translation>Varsayılan</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="82"/>
        <source>Video Size:</source>
        <translation>Video boyutu:</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="83"/>
        <source>Aspect:</source>
        <translation>Boyut:</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="84"/>
        <source>Frame Rate (fps):</source>
        <translation>Kare hızı (fps):</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="85"/>
        <source>Video Bitrate (kbps):</source>
        <translation>Video bit hızı (kpbs):</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="123"/>
        <source>Frequency (Hz):</source>
        <translation>Frekans (Hz):</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="656"/>
        <source>Channels:</source>
        <translation type="obsolete">Kanallar:</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="125"/>
        <source>Audio Bitrate (kbps):</source>
        <translation>Audio Bit hızı (kpbs):</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="291"/>
        <source>Error!</source>
        <translation>Hata!</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="299"/>
        <source>Neither ffmpeg nor avconv are installed.
You will not be able to convert audio/video files until you install one of them.</source>
        <translation type="obsolete">ffmpeg ve avconv yüklü değil.
Mezkur programlar yüklenmeden audio/video dosyaları dönüştürülemez.</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="778"/>
        <source>Extension must be one word and must not start with a dot.</source>
        <translation type="obsolete">Uzantı tek sözcükten oluşmalı ve nokta ile başlamamalı.</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="785"/>
        <source>The command LineEdit may not be empty.</source>
        <translation type="obsolete">Komut giriş satırı boş bırakılamaz.</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="108"/>
        <source>Preserve aspect ratio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="109"/>
        <source>Preserve video size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="124"/>
        <source>Audio Channels:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="156"/>
        <source>Split file. Begin time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="158"/>
        <source>Duration</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="164"/>
        <source>Embed subtitle:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="169"/>
        <source>Rotate:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="302"/>
        <source>Choose File</source>
        <translation type="unfinished">Dosya seçin</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="44"/>
        <source>None</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="46"/>
        <source>clockwise</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="52"/>
        <source>vertical flip</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="48"/>
        <source>counter clockwise</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="51"/>
        <source>horizontal flip</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="126"/>
        <source>Threads:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="291"/>
        <source>Neither ffmpeg nor libav are installed.
You will not be able to convert audio/video files until you install one of them.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CreditsDialog</name>
    <message>
        <location filename="../ffmulticonverter/about_dlg.py" line="70"/>
        <source>Written by</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/about_dlg.py" line="71"/>
        <source>Translated by</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/about_dlg.py" line="72"/>
        <source>&amp;Close</source>
        <translation>&amp;Kapat</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/about_dlg.py" line="82"/>
        <source>Credits</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DocumentTab</name>
    <message>
        <location filename="../ffmulticonverter/documenttab.py" line="41"/>
        <source>Convert:</source>
        <translation>Dönüştür:</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/documenttab.py" line="62"/>
        <source>Unocov is not installed.
You will not be able to convert document files until you install it.</source>
        <translation>Unocov yüklü değil.
Mezkur programlar yüklenmeden dökümanlar dönüştürülemez.</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/documenttab.py" line="75"/>
        <source>Error!</source>
        <translation>Hata!</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="1022"/>
        <source>%1 is not %2!</source>
        <translation type="obsolete">%1 %2 değil!</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/documenttab.py" line="70"/>
        <source>{0} is not {1}!</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ImageTab</name>
    <message>
        <location filename="../ffmulticonverter/imagetab.py" line="37"/>
        <source>Convert to:</source>
        <translation>Dönüştür:</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/imagetab.py" line="46"/>
        <source>Image Size:</source>
        <translation>Resim Boyutu:</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/imagetab.py" line="107"/>
        <source>Error!</source>
        <translation>Hata!</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="953"/>
        <source>PythonMagick is not installed.
You will not be able to convert image files until you install it.</source>
        <translation type="obsolete">PythonMagick yüklü değil.
Mezkur programlar yüklenmeden resimler dönüştürülemez.</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/imagetab.py" line="107"/>
        <source>The size LineEdit may not be empty.</source>
        <translation>Boyut giriş satırı boş bırakılamaz.</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/imagetab.py" line="57"/>
        <source>Maintain aspect ratio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/imagetab.py" line="40"/>
        <source>Extra options:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/imagetab.py" line="58"/>
        <source>Auto-crop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/imagetab.py" line="62"/>
        <source>Rotate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/imagetab.py" line="62"/>
        <source>degrees - clockwise</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/imagetab.py" line="102"/>
        <source>ImageMagick is not installed.
You will not be able to convert image files until you install it.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/imagetab.py" line="66"/>
        <source>Vertical flip</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/imagetab.py" line="67"/>
        <source>Horizontal flip</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="74"/>
        <source>Output folder:</source>
        <translation>Çıktı dizini:</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="86"/>
        <source>Audio/Video</source>
        <translation>Audio/Video</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="86"/>
        <source>Images</source>
        <translation>Resim</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="87"/>
        <source>Documents</source>
        <translation>Belge</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="96"/>
        <source>Delete original</source>
        <translation>Ana dosyayı sil</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="97"/>
        <source>&amp;Convert</source>
        <translation>&amp;Dönüştür</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="111"/>
        <source>Open</source>
        <translation>Aç</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="111"/>
        <source>Open a file</source>
        <translation>Bir dosya aç</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="115"/>
        <source>Convert</source>
        <translation>Dönüştür</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="115"/>
        <source>Convert files</source>
        <translation>Dosyaları dönüştür</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="119"/>
        <source>Quit</source>
        <translation>Çıkış</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="123"/>
        <source>Edit Presets</source>
        <translation>Ön ayarları düzenle</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="127"/>
        <source>Import</source>
        <translation>İçe aktar</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="127"/>
        <source>Import presets</source>
        <translation>Ön ayarları içe aktar</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="131"/>
        <source>Export</source>
        <translation>Dışa aktar</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="131"/>
        <source>Export presets</source>
        <translation>Ön ayarları dışa aktar</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="135"/>
        <source>Reset</source>
        <translation>Sıfırla</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="135"/>
        <source>Reset presets</source>
        <translation>Ön ayarları sıfırla</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="67"/>
        <source>Clear</source>
        <translation>Temizle</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="147"/>
        <source>Clear form</source>
        <translation>Formu temizle</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="151"/>
        <source>Preferences</source>
        <translation>Seçenekler</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="175"/>
        <source>About</source>
        <translation>Hakkında</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="180"/>
        <source>File</source>
        <translation>Dosya</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="181"/>
        <source>Edit</source>
        <translation>Düzen</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="182"/>
        <source>Presets</source>
        <translation>Ön ayarlar:</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="183"/>
        <source>Help</source>
        <translation>Yardım</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="326"/>
        <source>All Files</source>
        <translation>Tüm dosyalar</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="326"/>
        <source>Audio/Video Files</source>
        <translation>Audio/Video Dosyaları</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="327"/>
        <source>Image Files</source>
        <translation>Resim dosyaları</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="327"/>
        <source>Document Files</source>
        <translation>Belgeler</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="335"/>
        <source>Choose File</source>
        <translation>Dosya seçin</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="386"/>
        <source>Choose output destination</source>
        <translation>Kayıt konumunu belirleyin</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="424"/>
        <source>You must choose an output folder!</source>
        <translation>Kayıt dizinini belirleyin!</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="428"/>
        <source>Output folder does not exists!</source>
        <translation>Kayıt dizini bulunamadı!</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="434"/>
        <source>Error!</source>
        <translation>Hata!</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="444"/>
        <source>Convert among several file types to other extensions</source>
        <translation type="obsolete">Dosya türlerini diğer uzantılara dönüştürün</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="254"/>
        <source>Missing dependencies:</source>
        <translation>Eksik bağımlılıklar:</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="65"/>
        <source>Add</source>
        <translation>Ekle</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="66"/>
        <source>Delete</source>
        <translation>Sil</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="147"/>
        <source>Clear All</source>
        <translation>Tümünü sil</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="421"/>
        <source>You must add at least one file to convert!</source>
        <translation>Dönüştürmek için en az bir dosya seçin!</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="94"/>
        <source>Save each file in the same
folder as input file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="139"/>
        <source>Synchronize</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="139"/>
        <source>Synchronize presets</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="143"/>
        <source>Remove old</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="143"/>
        <source>Remove old presets</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="170"/>
        <source>documentation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/ffmulticonverter.py" line="487"/>
        <source>Convert among several file types to other formats</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Preferences</name>
    <message>
        <location filename="../ffmulticonverter/preferences_dlg.py" line="43"/>
        <source>Save files</source>
        <translation>Dosyaları kaydet</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/preferences_dlg.py" line="44"/>
        <source>Existing files:</source>
        <translation>Var olan dosyalar:</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/preferences_dlg.py" line="45"/>
        <source>Add &apos;~&apos; prefix</source>
        <translation>&apos;~&apos; ön ek ekle</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/preferences_dlg.py" line="46"/>
        <source>Overwrite</source>
        <translation>Üzerine yaz</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/preferences_dlg.py" line="50"/>
        <source>Default output destination:</source>
        <translation>Kayıt konumunu varsayılana ayarla:</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/preferences_dlg.py" line="56"/>
        <source>Name files</source>
        <translation>Dosyaları adlandır</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/preferences_dlg.py" line="57"/>
        <source>Prefix:</source>
        <translation>Ön ek:</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/preferences_dlg.py" line="58"/>
        <source>Suffix:</source>
        <translation>Son ek:</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/preferences_dlg.py" line="73"/>
        <source>FFmpeg</source>
        <translation>FFmpeg</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/preferences_dlg.py" line="74"/>
        <source>Default command:</source>
        <translation>Varsayılan komut:</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/preferences_dlg.py" line="76"/>
        <source>Use:</source>
        <translation type="obsolete">Kullanım:</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/preferences_dlg.py" line="78"/>
        <source>avconv</source>
        <translation type="obsolete">avconv</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/preferences_dlg.py" line="108"/>
        <source>General</source>
        <translation>Genel</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/preferences_dlg.py" line="109"/>
        <source>Audio/Video</source>
        <translation>Ses/Video</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/preferences_dlg.py" line="124"/>
        <source>Preferences</source>
        <translation>Seçenekler</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/preferences_dlg.py" line="177"/>
        <source>Choose default output destination</source>
        <translation>Varsayılan kayıt konumunu seç</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/preferences_dlg.py" line="77"/>
        <source>Video codecs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/preferences_dlg.py" line="80"/>
        <source>Audio codecs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/preferences_dlg.py" line="83"/>
        <source>Extra formats</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/preferences_dlg.py" line="91"/>
        <source>Default video codecs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/preferences_dlg.py" line="92"/>
        <source>Default audio codecs</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Progress</name>
    <message>
        <location filename="../ffmulticonverter/progress.py" line="70"/>
        <source>In progress: </source>
        <translation>İşlem:</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/progress.py" line="71"/>
        <source>Total:</source>
        <translation>Toplam:</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/progress.py" line="76"/>
        <source>Cancel</source>
        <translation>Durdur</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/progress.py" line="78"/>
        <source>Details</source>
        <translation>Ayrıntılar</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/progress.py" line="111"/>
        <source>Conversion</source>
        <translation>Dönüştürme</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/progress.py" line="172"/>
        <source>Converted: %1/%2</source>
        <translation type="obsolete">Converted: %1/%2</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/progress.py" line="208"/>
        <source>Cancel Conversion</source>
        <translation>Dönüştürmeyi durdur</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/progress.py" line="208"/>
        <source>Are you sure you want to cancel conversion?</source>
        <translation>Dönüştürmeyi durdurmak istediğinizden emin misiniz ?</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/progress.py" line="244"/>
        <source>In progress:</source>
        <translation>İşlem:</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/progress.py" line="176"/>
        <source>Report</source>
        <translation>Raporla</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/progress.py" line="181"/>
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/progress.py" line="177"/>
        <source>Converted: {0}/{1}</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ShowPresets</name>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="43"/>
        <source>Preset label</source>
        <translation>Ön ayar etiketi</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="46"/>
        <source>Preset command line parameters</source>
        <translation>Ön ayar komut satırı değişkenleri</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="49"/>
        <source>Output file extension</source>
        <translation>Çıktı dosyası uzantısı</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="52"/>
        <source>Add</source>
        <translation>Ekle</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="53"/>
        <source>Delete</source>
        <translation>Sil</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="54"/>
        <source>Delete all</source>
        <translation>Tümünü sil</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="55"/>
        <source>Edit</source>
        <translation>Düzenle</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="58"/>
        <source>OK</source>
        <translation>Tamam</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="95"/>
        <source>Edit Presets</source>
        <translation>Ön ayarları düzenle</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="288"/>
        <source>Delete Preset</source>
        <translation>Ön ayarı sil</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="184"/>
        <source>Are you sure that you want to delete the %1 preset?</source>
        <translation type="obsolete">%1 ön ayarını silmek istediğinizden emin misiniz ?</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="200"/>
        <source>Are you sure that you want to delete all presets?</source>
        <translation>Tüm ön ayarları silmek istediğinzden emin misiniz ?</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="257"/>
        <source>All current presets will be deleted.
Are you sure that you want to continue?</source>
        <translation>Tüm mevcut ön ayarlar silinecek.
Devam etmek istediğinizden emin misiniz ?</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="288"/>
        <source>Are you sure that you want to restore the default presets?</source>
        <translation>Varsayılan ön ayarları geri yüklemek istediğinizden emin misiniz ?</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="267"/>
        <source>Import failed!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="56"/>
        <source>Search</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="308"/>
        <source>Presets Synchronization</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="308"/>
        <source>Current presets and default presets will be merged. Are you sure that you want to continue?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="357"/>
        <source>Remove old presets</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="186"/>
        <source>Are you sure that you want to delete the {0} preset?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="275"/>
        <source>Export presets</source>
        <translation type="unfinished">Ön ayarları dışa aktar</translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="357"/>
        <source>All presets with an __OLD suffix will be deleted. Are you sure that you want to continue?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="263"/>
        <source>Successful import!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="295"/>
        <source>Default presets restored successfully.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="351"/>
        <source>Synchronization completed.
Your presets are up to date!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ffmulticonverter/presets_dlgs.py" line="372"/>
        <source>Old presets successfully removed.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Tab</name>
    <message>
        <location filename="../ffmulticonverter/audiovideotab.py" line="184"/>
        <source>More</source>
        <translation>Daha fazla</translation>
    </message>
</context>
</TS>
